v {xschem version=3.4.6 file_version=1.2}
G {}
K {}
V {}
S {}
E {}
N 820 -280 980 -280 {lab=Vout}
N 980 -170 980 -150 {lab=GND}
N 980 -280 980 -230 {lab=Vout}
N 460 -190 460 -150 {lab=GND}
N 280 -250 330 -250 {lab=#net1}
N 280 -250 280 -220 {lab=#net1}
N 780 -280 820 -280 {lab=Vout}
N 270 -440 270 -415 {lab=GND}
N 270 -520 270 -500 {lab=VDD}
N 540 -310 580 -310 {lab=#net2}
N 700 -470 820 -470 {lab=Vout}
N 540 -470 640 -470 {lab=#net2}
N 660 -380 660 -350 {lab=VDD}
N 390 -250 580 -250 {lab=#net3}
N 660 -210 660 -190 {lab=GND}
N 500 -310 540 -310 {lab=#net2}
N 230 -310 440 -310 {lab=#net4}
N 820 -470 820 -280 {lab=Vout}
N 540 -470 540 -310 {lab=#net2}
C {vdd.sym} 660 -380 0 0 {name=l4 lab=VDD}
C {capa.sym} 980 -200 0 0 {name=C1
m=1
value=50p
footprint=1206
device="ceramic capacitor"}
C {gnd.sym} 980 -150 0 0 {name=l6 lab=GND}
C {devices/launcher.sym} 620 -10 0 0 {name=h1
descr="load op & annotate" 
tclcommand="xschem raw_read $netlist_dir/RamP_tb1_CP_FB1.raw; set show_hidden_texts 1; xschem annotate_op"}
C {ngspice_probe.sym} 980 -280 0 0 {name=r2}
C {lab_pin.sym} 980 -280 0 1 {name=p1 sig_type=std_logic lab=Vout}
C {capa.sym} 360 -250 3 0 {name=C3
m=1
value=2p
footprint=1206
device="ceramic capacitor"}
C {res.sym} 460 -220 2 0 {name=R3
value=400e6
footprint=1206
device=resistor
m=1}
C {gnd.sym} 460 -150 0 0 {name=l1 lab=GND}
C {vsource.sym} 280 -190 0 0 {name=V1 value="0 ac 1" savecurrent=false}
C {gnd.sym} 280 -160 0 0 {name=l2 lab=GND}
C {code_shown.sym} 0 -90 0 0 {
name=TT_MODELS
only_toplevel=true
value="
** IHP models
.lib cornerMOSlv.lib mos_tt
.lib cornerMOShv.lib mos_tt
"
spice_ignore=false
      }
C {devices/code_shown.sym} 0 -410 0 0 {name="NGSPICE" only_toplevel=true 
value="
.option wnflag=1
.option savecurrents
.temp 27
.control
save all
write RAMP_HPF.raw
set appendwrite 
op
write RAMP_HPF.raw
**dc temp -50 150 1
ac dec 20 1 1e8
plot vdb(Vout)
.endc
"}
C {vsource.sym} 270 -470 0 0 {name=V2 value="dc 1.65" savecurrent=false}
C {vdd.sym} 270 -520 0 0 {name=l7 lab=VDD}
C {gnd.sym} 270 -415 0 0 {name=l8 lab=GND}
C {/foss/designs/RAMP/Fully-Diff-RAMP/RAMP.sym} 400 -280 2 1 {name=x2}
C {res.sym} 670 -470 1 0 {name=R1
value=900k
footprint=1206
device=resistor
m=1}
C {res.sym} 470 -310 3 1 {name=R6
value=100k
footprint=1206
device=resistor
m=1}
C {gnd.sym} 660 -190 0 0 {name=l3 lab=GND}
C {ngspice_probe.sym} 540 -430 0 1 {name=r4}
C {ngspice_probe.sym} 540 -250 0 0 {name=r5}
C {vsource.sym} 230 -280 0 0 {name=V3 value=0.825 savecurrent=false}
C {gnd.sym} 230 -250 0 0 {name=l5 lab=GND}
